// Dragon Shifter Transformation Script
// Module: dragon-shifter
// Place in your module's scripts/ folder as dragon-shifter.js
// Updated for FoundryVTT v14 / dnd5e v4+ compatibility

console.log("%c[Dragon Shifter] Script file parsed. Hooks will register on init.", "color: #d4af37; font-weight: bold;");

/* ────────────────────────────────────────────────────────────────────────────
   HELPERS
   ──────────────────────────────────────────────────────────────────────────── */

function isPolymorphed(actor) {
    if (!actor) return false;
    const hasOriginal = !!foundry.utils.getProperty(actor, "flags.dnd5e.originalActor");
    const result = actor.isPolymorphed || hasOriginal;
    return result;
}

function isDragonFormByName(name) {
    if (!name) return false;
    const n = name.toLowerCase();
    return n.includes("dragon form") || n.includes("draconic form");
}

function getFormTypeFromName(name) {
    if (!name) return "adult";
    const n = name.toLowerCase();
    if (n.includes("wyrmling")) return "wyrmling";
    if (n.includes("young"))    return "young";
    return "adult";
}

function getDragonClass(actor) {
    if (!actor) return null;
    const byId = actor.classes?.dragon;
    if (byId) return byId;
    return actor.items?.find(i => i.type === "class" && /dragon/i.test(i.name));
}

/* ────────────────────────────────────────────────────────────────────────────
   FORM UNLOCK REQUIREMENTS (by Dragon class level)
   ──────────────────────────────────────────────────────────────────────────── */

const FORM_REQUIREMENTS = {
    wyrmling: { reqLevel: 3,  maxUses: 1 },
    young:    { reqLevel: 8,  maxUses: 2 },
    adult:    { reqLevel: 15, maxUses: 3 }
};

function getFormUnlockStatus(formType, dragonLevel) {
    const req = FORM_REQUIREMENTS[formType];
    if (!req) return { unlocked: false, maxUses: 0 };
    return {
        unlocked: dragonLevel >= req.reqLevel,
        maxUses: req.maxUses
    };
}

async function getOrCreateFormTracker(actor, formType, featureName, maxUses) {
    let item = actor.items.find(i => i.name === featureName);
    if (item) return item;

    console.log(`[Dragon Shifter] Creating temporary use tracker for ${featureName}`);
    const trackerData = {
        name: featureName,
        type: "feat",
        system: {
            description: { value: "", chat: "" },
            source: { rules: "2024", revision: 1 },
            identifier: `draconic-form-${formType}`,
            type: { value: "class", subtype: "" },
            uses: {
                spent: 0,
                recovery: [{ period: "lr", type: "recoverAll" }],
                max: String(maxUses)
            }
        },
        flags: {
            "taos": {
                isTempTracker: true,
                formType: formType
            }
        }
    };
    item = await actor.createEmbeddedDocuments("Item", [trackerData]);
    return item[0];
}

/* ────────────────────────────────────────────────────────────────────────────
   READY
   ──────────────────────────────────────────────────────────────────────────── */

Hooks.on("ready", () => {
    console.log("%c[Dragon Shifter] READY — script is active.", "color: #d4af37; font-weight: bold;");
    for (const actor of game.actors) {
        const data = actor.getFlag("taos", "transformData");
        if (data && isPolymorphed(actor)) {
            console.log(`[Dragon Shifter] Resuming timer for ${actor.name}`);
            checkFeralStatus(actor, true);
        }
    }
});

/* ────────────────────────────────────────────────────────────────────────────
   DRAG-SHEET DROP INTERCEPT
   ──────────────────────────────────────────────────────────────────────────── */

Hooks.on("dropActorSheetData", async (actor, sheet, data) => {
    console.log("[Dragon Shifter] dropActorSheetData fired:", {
        actorName: actor?.name,
        actorType: actor?.type,
        dataType: data?.type,
        dataUuid: data?.uuid,
        dataId: data?.id
    });

    if (data.type !== "Actor") {
        console.log("[Dragon Shifter] dropActorSheetData: Not an Actor drop. Skipping.");
        return;
    }

    const dragonClass = getDragonClass(actor);
    if (!dragonClass) {
        console.log("[Dragon Shifter] dropActorSheetData: Actor does not have Dragon class.");
        return;
    }

    let droppedActorName = "";
    if (data.uuid) {
        try {
            const droppedActor = fromUuidSync(data.uuid);
            droppedActorName = droppedActor?.name || "";
        } catch (e) {
            console.warn("[Dragon Shifter] fromUuidSync failed:", e);
        }
    }
    if (!droppedActorName && data.id) {
        const droppedActor = game.actors.get(data.id);
        droppedActorName = droppedActor?.name || "";
    }

    console.log(`[Dragon Shifter] dropActorSheetData: Dropped actor name = "${droppedActorName}"`);

    if (!isDragonFormByName(droppedActorName)) {
        console.log(`[Dragon Shifter] dropActorSheetData: "${droppedActorName}" is not a dragon form.`);
        return;
    }

    console.log(`[Dragon Shifter] dropActorSheetData: DETECTED dragon form "${droppedActorName}"`);

    const formType = getFormTypeFromName(droppedActorName);
    const dragonLevel = dragonClass.system?.levels || 1;

    const unlockStatus = getFormUnlockStatus(formType, dragonLevel);
    if (!unlockStatus.unlocked) {
        ui.notifications.warn(`Draconic Form (${formType}) unlocks at Dragon level ${FORM_REQUIREMENTS[formType].reqLevel}. You are level ${dragonLevel}.`);
        console.warn(`[Dragon Shifter] Blocking: ${formType} requires level ${FORM_REQUIREMENTS[formType].reqLevel}, player is ${dragonLevel}.`);
        return false;
    }

    const tempHPMultiplier = formType === "wyrmling" ? 7 :
                             formType === "young"    ? 9 : 11;
    const tempHP = dragonLevel * tempHPMultiplier;

    const featureName = `Draconic Form: ${formType.charAt(0).toUpperCase() + formType.slice(1)}`;

    // ─── Check uses and deduct BEFORE transform ───
    let featureItem = actor.items.find(i => i.name === featureName);
    if (!featureItem) {
        console.log(`[Dragon Shifter] Feat item "${featureName}" not found. Creating temp tracker.`);
        featureItem = await getOrCreateFormTracker(actor, formType, featureName, unlockStatus.maxUses);
    }

    const spent = featureItem.system?.uses?.spent ?? 0;
    const max   = featureItem.system?.uses?.max   ?? unlockStatus.maxUses;
    if (spent >= max) {
        ui.notifications.warn(`No uses of ${featureName} remaining. Complete a Long Rest to recover.`);
        console.warn(`[Dragon Shifter] Blocking: no uses remaining (${spent}/${max}).`);
        return false;
    }

    // Deduct use now, before the transform
    await featureItem.update({"system.uses.spent": spent + 1});
    console.log(`[Dragon Shifter] Deducted 1 use from ${featureName}. Now ${spent + 1}/${max}.`);

    // Store pending transform data on the ORIGINAL actor
    await actor.setFlag("taos", "pendingTransform", {
        formName: droppedActorName,
        formType: formType,
        dragonLevel: dragonLevel,
        tempHP: tempHP,
        featureName: featureName,
        maxUses: unlockStatus.maxUses,
        originalHP: {
            max:     actor.system.attributes.hp.max,
            value:   actor.system.attributes.hp.value,
            temp:    actor.system.attributes.hp.temp || 0,
            tempmax: actor.system.attributes.hp.tempmax || 0
        }
    });
    console.log("[Dragon Shifter] dropActorSheetData: Stored pendingTransform flag.");
});

/* ────────────────────────────────────────────────────────────────────────────
   dnd5e.transformActor hook — SYNCHRONOUS, only passes data to new actor
   ──────────────────────────────────────────────────────────────────────────── */

Hooks.on("dnd5e.transformActor", (actor, target, data, options) => {
    console.log("[Dragon Shifter] dnd5e.transformActor fired:", {
        actor: actor?.name,
        target: target?.name
    });

    const pending = actor.getFlag("taos", "pendingTransform");
    if (!pending) {
        console.log("[Dragon Shifter] transformActor: No pendingTransform flag. Skipping.");
        return;
    }

    console.log("[Dragon Shifter] transformActor: Found pendingTransform. Passing data to new actor.");

    // Synchronously set flags on the data object that will become the new actor
    data.flags = data.flags || {};
    data.flags["taos"] = data.flags["taos"] || {};
    data.flags["taos"].pendingTempHP = pending.tempHP;
    data.flags["taos"].transformData = {
        formType: pending.formType,
        transformWorldTime: game.time.worldTime,
        safeDuration: pending.dragonLevel,
        feralDC: 10,
        hoursPastLimit: 0,
        isFeral: false
    };
    // Flag to indicate post-transform processing is needed
    data.flags["taos"].postTransformPending = true;
    // Store original actor ID for reference
    data.flags["taos"].originalActorId = actor.id;

    console.log("[Dragon Shifter] transformActor: Set flags on data object for new actor.");

    ui.notifications.info(`Transforming into ${pending.formType} form! Temp HP: ${pending.tempHP}. Safe duration: ${pending.dragonLevel} hours.`);
});

/* ────────────────────────────────────────────────────────────────────────────
   Post-transform: createActor hook — fires AFTER the new actor is created
   ──────────────────────────────────────────────────────────────────────────── */

Hooks.on("createActor", async (actor, options, userId) => {
    // Guard: only process our dragon-shifter transforms
    if (!isPolymorphed(actor)) return;
    if (!actor.getFlag("taos", "postTransformPending")) return;

    console.log("[Dragon Shifter] createActor: Post-transform processing for", actor.name);

    // Set processing flag to show banner
    await actor.setFlag("taos", "postTransformProcessing", true);

    try {
        // ─── Find original actor ───
        const originalActorId = actor.getFlag("taos", "originalActorId");
        const originalActor = game.actors.get(originalActorId);
        if (!originalActor) {
            console.warn("[Dragon Shifter] createActor: Could not find original actor. Skipping item copy.");
        } else {
            console.log("[Dragon Shifter] createActor: Found original actor:", originalActor.name);

            // DEBUG: Log all item types on original actor
            const allItems = originalActor.items.map(i => ({ name: i.name, type: i.type }));
            console.log("[Dragon Shifter] DEBUG: All items on original actor:", allItems);

            // ─── Copy species item (check both "species" and "race" for 2024/legacy compatibility) ───
            let speciesItem = originalActor.items.find(i => i.type === "species");
            if (!speciesItem) {
                speciesItem = originalActor.items.find(i => i.type === "race");
                if (speciesItem) console.log("[Dragon Shifter] createActor: Found species as 'race' type:", speciesItem.name);
            }
            if (speciesItem) {
                const speciesData = speciesItem.toObject(true);
                delete speciesData._id; // Fresh ID to avoid revert conflicts
                delete speciesData.folder;
                delete speciesData.sort;
                await actor.createEmbeddedDocuments("Item", [speciesData]);
                console.log("[Dragon Shifter] createActor: Copied species item:", speciesData.name);
            } else {
                console.log("[Dragon Shifter] createActor: No species item found on original actor (checked 'species' and 'race').");
            }

            // ─── Copy background item ───
            const backgroundItem = originalActor.items.find(i => i.type === "background");
            if (backgroundItem) {
                const bgData = backgroundItem.toObject(true);
                delete bgData._id;
                delete bgData.folder;
                delete bgData.sort;
                await actor.createEmbeddedDocuments("Item", [bgData]);
                console.log("[Dragon Shifter] createActor: Copied background item:", bgData.name);
            } else {
                console.log("[Dragon Shifter] createActor: No background item found on original actor (checked 'background').");
            }

            // ─── Copy spell items ───
            const spellItems = originalActor.items.filter(i => i.type === "spell");
            if (spellItems.length > 0) {
                const spellData = spellItems.map(i => {
                    const d = i.toObject(true);
                    delete d._id;
                    delete d.folder;
                    delete d.sort;
                    return d;
                });
                await actor.createEmbeddedDocuments("Item", spellData);
                console.log(`[Dragon Shifter] createActor: Copied ${spellData.length} spell items.`);
            } else {
                console.log("[Dragon Shifter] createActor: No spell items found on original actor.");
            }

            // ─── Copy feat items (Dragon class features) ───
            const featItems = originalActor.items.filter(i => i.type === "feat");
            if (featItems.length > 0) {
                const featData = featItems.map(i => {
                    const d = i.toObject(true);
                    delete d._id;
                    delete d.folder;
                    delete d.sort;
                    return d;
                });
                await actor.createEmbeddedDocuments("Item", featData);
                console.log(`[Dragon Shifter] createActor: Copied ${featData.length} feat items.`);
            } else {
                console.log("[Dragon Shifter] createActor: No feat items found on original actor.");
            }
        }

        // ─── Bug 4: Restore original HP max/value ───
        if (originalActor) {
            const pending = originalActor.getFlag("taos", "pendingTransform");
            if (pending && pending.originalHP) {
                const currentHP = actor.system.attributes.hp;
                const updates = {};

                if (currentHP.max !== pending.originalHP.max || currentHP.max === 0 || !currentHP.max) {
                    updates["system.attributes.hp.max"] = pending.originalHP.max;
                    console.log("[Dragon Shifter] Bug 4: Restoring HP max to", pending.originalHP.max);
                }
                if (currentHP.value !== pending.originalHP.value || currentHP.value === 0) {
                    const maxHP = updates["system.attributes.hp.max"] || currentHP.max || pending.originalHP.max;
                    const newValue = Math.min(pending.originalHP.value, maxHP);
                    updates["system.attributes.hp.value"] = newValue;
                    console.log("[Dragon Shifter] Bug 4: Restoring HP value to", newValue);
                }

                if (Object.keys(updates).length > 0) {
                    await actor.update(updates, { dragonShifterHP: true });
                }
            }
        }

        // ─── Bug 5: Apply temp HP ───
        const pendingTemp = actor.getFlag("taos", "pendingTempHP");
        if (pendingTemp !== undefined && pendingTemp !== null) {
            await actor.update({ "system.attributes.hp.temp": pendingTemp }, { dragonShifterTempHP: true });
            console.log("[Dragon Shifter] Bug 5: Applied temp HP:", pendingTemp);
            await actor.unsetFlag("taos", "pendingTempHP");
        }

    } catch (err) {
        console.error("[Dragon Shifter] createActor: Error during post-transform processing:", err);
    } finally {
        // Mark processing complete, remove pending flag
        await actor.unsetFlag("taos", "postTransformPending");
        await actor.setFlag("taos", "postTransformProcessing", false);
        console.log("[Dragon Shifter] createActor: Post-transform processing complete.");
    }

    // ─── Workaround for dnd5e v4+ polymorph refresh bug (GitHub #1463) ───
    // Force a sheet close and re-open to ensure the new actor's sheet is properly rendered
    setTimeout(async () => {
        const sheet = actor.sheet;
        if (sheet) {
            console.log("[Dragon Shifter] Forcing sheet refresh to fix polymorph header bug.");
            if (sheet.rendered) {
                await sheet.close();
                await new Promise(r => setTimeout(r, 100));
            }
            actor.sheet?.render(true);
        } else {
            actor.sheet?.render(true);
        }
    }, 200);
});

/* ────────────────────────────────────────────────────────────────────────────
   updateActor hook — fallback post-transform path
   ──────────────────────────────────────────────────────────────────────────── */

Hooks.on("updateActor", async (actor, change, options, userId) => {
    // Prevent recursive updates
    if (options?.dragonShifterHP || options?.dragonShifterTempHP) return;

    // Only process if polymorphed and has our pending flag
    if (!isPolymorphed(actor)) return;
    const pendingTemp = actor.getFlag("taos", "pendingTempHP");
    if (pendingTemp === undefined || pendingTemp === null) return;

    console.log("[Dragon Shifter] updateActor: Fallback temp HP application for", actor.name);

    const currentTemp = actor.system?.attributes?.hp?.temp || 0;
    if (currentTemp !== pendingTemp) {
        await actor.update({ "system.attributes.hp.temp": pendingTemp }, { dragonShifterTempHP: true });
        console.log("[Dragon Shifter] updateActor: Applied temp HP:", pendingTemp);
    }
    await actor.unsetFlag("taos", "pendingTempHP");
});

/* ────────────────────────────────────────────────────────────────────────────
   HEADER CONTROLS — Revert Button (dnd5e v4+ specific hooks)
   ──────────────────────────────────────────────────────────────────────────── */

/**
 * Add revert button to dnd5e v4 actor sheet header controls.
 * Uses the dnd5e-specific hooks:
 * - getHeaderControlsBaseActorSheet (for all actor sheets)
 * - getHeaderControlsDocumentSheetV2 (generic DocumentSheetV2 fallback)
 */
function addRevertHeaderControl(app, controls) {
    const actor = app.actor || app.document;
    if (!actor || actor.documentName !== "Actor") return;

    if (!isPolymorphed(actor)) return;
    if (!actor.getFlag("taos", "transformData")) return;

    controls.push({
        icon: "fas fa-undo",
        label: "Revert to Humanoid Form",
        action: "dragonShifterRevert"
    });

    console.log("[Dragon Shifter] Added revert button to header controls for", actor.name);
}

Hooks.on("getHeaderControlsBaseActorSheet", addRevertHeaderControl);
Hooks.on("getHeaderControlsDocumentSheetV2", addRevertHeaderControl);

/**
 * Handle the dragonShifterRevert action on actor sheets.
 * Patches the sheet's actions object to include our custom action.
 */
function patchSheetActions(app, html, data) {
    const actor = app.actor;
    if (!actor || !isPolymorphed(actor)) return;
    if (!actor.getFlag("taos", "transformData")) return;

    // For ApplicationV2 sheets, actions are handled via the actions object.
    if (app.actions && !app.actions.dragonShifterRevert) {
        app.actions.dragonShifterRevert = async function(event, target) {
            event.preventDefault();
            event.stopPropagation();
            if (!actor.isOwner) {
                ui.notifications.warn("You do not have permission to revert this form.");
                return;
            }
            await actor.revertOriginalForm();
        };
        console.log("[Dragon Shifter] Registered dragonShifterRevert action handler on sheet.", app.constructor.name);
    }

    // Also inject the status panel into the sheet body
    injectStatusPanel(app, html, actor);
}

// Register on dnd5e v4 specific render hooks
Hooks.on("renderCharacterActorSheet", patchSheetActions);
Hooks.on("renderNPCActorSheet", patchSheetActions);
Hooks.on("renderGroupActorSheet", patchSheetActions);

// V2 generic actor sheet hook (catches polymorphed NPC sheets)
Hooks.on("renderActorSheetV2", patchSheetActions);

// Fallback: also register on generic renderActorSheet for legacy sheets
Hooks.on("renderActorSheet", patchSheetActions);

/**
 * Inject the Dragon Form status panel into the sheet.
 * Injects into the sheet's header / title bar area where existing controls live.
 */
function injectStatusPanel(app, html, actor) {
    // Remove any existing panel for this actor
    const existing = document.querySelector(`.dragon-shifter-panel[data-actor-id="${actor.id}"]`);
    if (existing) existing.remove();

    const transformData = actor.getFlag("taos", "transformData");
    const isProcessing = actor.getFlag("taos", "postTransformProcessing");

    // ─── Determine status color and tooltip ───
    let statusColor, statusTooltip, statusIcon;
    if (isProcessing) {
        statusColor = "#d4af37";
        statusTooltip = "Applying transformation...";
        statusIcon = "fa-dragon";
    } else if (transformData) {
        const now = game.time.worldTime;
        const elapsedSeconds = now - transformData.transformWorldTime;
        const elapsedHours   = elapsedSeconds / 3600;
        const remaining      = Math.max(0, transformData.safeDuration - elapsedHours);
        const hoursOver      = Math.max(0, elapsedHours - transformData.safeDuration);
        const nextFeralDC    = 10 + Math.ceil(hoursOver);
        const elapsedH = Math.floor(elapsedHours);
        const elapsedM = Math.floor((elapsedHours - elapsedH) * 60);
        const remainH  = Math.floor(remaining);
        const remainM  = Math.floor((remaining - remainH) * 60);

        if (transformData.isFeral) {
            statusColor = "#8b0000";
            statusTooltip = `FERAL — ${actor.name} has lost control!`;
            statusIcon = "fa-skull-crossbones";
        } else if (hoursOver > 0) {
            statusColor = "#ff8c00";
            statusTooltip = `Over limit! DC ${nextFeralDC} Wis save required. Elapsed: ${elapsedH}h ${elapsedM}m`;
            statusIcon = "fa-exclamation-triangle";
        } else {
            statusColor = "#228b22";
            statusTooltip = `${transformData.formType.charAt(0).toUpperCase() + transformData.formType.slice(1)} form — ${remainH}h ${remainM}m remaining`;
            statusIcon = "fa-check";
        }
    } else {
        statusColor = "#555";
        statusTooltip = "Dragon Form active";
        statusIcon = "fa-dragon";
    }

    // ─── Build the panel ───
    const panel = document.createElement("div");
    panel.className = "dragon-shifter-panel";
    panel.dataset.actorId = actor.id;
    panel.style.cssText = `
        display: inline-flex;
        align-items: center;
        gap: 4px;
        margin-left: 6px;
        pointer-events: auto;
        vertical-align: middle;
    `;

    // Status dot (colored circle with icon)
    const statusDot = document.createElement("span");
    statusDot.style.cssText = `
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: ${statusColor};
        color: white;
        font-size: 9px;
        cursor: help;
        box-shadow: 0 1px 3px rgba(0,0,0,0.4);
        border: 1px solid rgba(255,255,255,0.3);
        flex-shrink: 0;
    `;
    statusDot.innerHTML = `<i class="fas ${statusIcon}"></i>`;
    statusDot.title = statusTooltip;
    panel.appendChild(statusDot);

    // Revert button — tiny icon-only, like wildshape
    if (!isProcessing) {
        const revertBtn = document.createElement("button");
        revertBtn.type = "button";
        revertBtn.title = "Revert to Humanoid Form";
        revertBtn.style.cssText = `
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            padding: 0;
            margin: 0;
            background: #e67e22;
            color: white;
            border: 1px solid #d35400;
            border-radius: 3px;
            font-size: 9px;
            cursor: pointer;
            box-shadow: 0 1px 3px rgba(0,0,0,0.3);
            line-height: 1;
            flex-shrink: 0;
        `;
        revertBtn.innerHTML = '<i class="fas fa-play" style="transform: rotate(180deg); font-size: 8px;"></i>';
        revertBtn.onmouseenter = () => { revertBtn.style.background = "#d35400"; };
        revertBtn.onmouseleave = () => { revertBtn.style.background = "#e67e22"; };
        revertBtn.addEventListener("click", async () => {
            if (!actor.isOwner) return ui.notifications.warn("You do not have permission to revert this form.");
            await actor.revertOriginalForm();
        });
        panel.appendChild(revertBtn);
    }

    // ─── Find the header and inject ───
    // Strategy 1: Try app.element (the actual window DOM)
    let headerTarget = null;
    if (app.element) {
        const el = app.element instanceof jQuery ? app.element[0] : app.element;
        // Look for the header actions / controls area in V2 sheets
        headerTarget = el.querySelector(".window-header .header-actions")
            || el.querySelector(".window-header .actions")
            || el.querySelector("[data-application-part='header'] .actions")
            || el.querySelector(".header-actions")
            || el.querySelector(".sheet-header-actions");
    }

    // Strategy 2: Search all open windows for one with this actor's name
    if (!headerTarget) {
        const allWindows = document.querySelectorAll(".app, .application, .window-app");
        for (const win of allWindows) {
            const titleEl = win.querySelector(".window-title");
            if (titleEl && titleEl.textContent.includes(actor.name)) {
                headerTarget = win.querySelector(".header-actions")
                    || win.querySelector(".actions")
                    || win.querySelector(".window-header-actions");
                if (headerTarget) break;
            }
        }
    }

    // Strategy 3: Try the html parameter's header
    if (!headerTarget) {
        const htmlEl = html instanceof jQuery ? html[0] : html;
        if (htmlEl && htmlEl instanceof Element) {
            headerTarget = htmlEl.querySelector(".header-actions")
                || htmlEl.querySelector("[data-application-part='header']")
                || htmlEl.querySelector(".sheet-header");
        }
    }

    if (headerTarget) {
        headerTarget.appendChild(panel);
        console.log("[Dragon Shifter] Injected status panel into header actions.");
        return;
    }

    // ─── FALLBACK: Inject as floating overlay with very high z-index ───
    console.warn("[Dragon Shifter] Header not found, using body overlay fallback.");

    const overlay = document.createElement("div");
    overlay.className = "dragon-shifter-overlay";
    overlay.dataset.actorId = actor.id;
    overlay.style.cssText = `
        position: fixed;
        top: 50px;
        right: 120px;
        z-index: 999999;
        display: flex;
        align-items: center;
        gap: 4px;
        pointer-events: auto;
    `;

    // Clone the panel contents into the overlay
    overlay.innerHTML = panel.innerHTML;

    // Re-attach click handler to the revert button in the overlay
    const revertBtn = overlay.querySelector("button");
    if (revertBtn) {
        revertBtn.addEventListener("click", async () => {
            if (!actor.isOwner) return ui.notifications.warn("You do not have permission to revert this form.");
            await actor.revertOriginalForm();
        });
    }

    document.body.appendChild(overlay);
    console.log("[Dragon Shifter] Injected status panel as fixed body overlay.");
}

/* ────────────────────────────────────────────────────────────────────────────
   BUG 6  —  Draconic Form Uses Tracker (on base character sheet)
   ──────────────────────────────────────────────────────────────────────────── */

function injectUsesTracker(app, html, data) {
    const actor = app.actor;
    if (!actor) return;

    if (isPolymorphed(actor)) return;

    const dragonClass = getDragonClass(actor);
    if (!dragonClass) return;

    const element = html instanceof jQuery ? html[0] : html;
    if (!element || !(element instanceof Element)) {
        console.warn("[Dragon Shifter] injectUsesTracker: html is not a valid DOM element.");
        return;
    }
    if (element.querySelector(".dragon-shifter-uses")) return;

    const forms = [
        { key: "wyrmling", label: "Wyrmling", reqLevel: 3,  max: 1 },
        { key: "young",    label: "Young",    reqLevel: 8,  max: 2 },
        { key: "adult",    label: "Adult",    reqLevel: 15, max: 3 }
    ];

    const dragonLevel = dragonClass.system?.levels || 1;
    const unlockedForms = forms.filter(f => dragonLevel >= f.reqLevel);
    if (unlockedForms.length === 0) return;

    let usesHTML = '<div class="dragon-shifter-uses" style="display: inline-flex; margin: 4px 0; padding: 4px 8px; background: rgba(0,0,0,0.05); border: 1px solid var(--color-border-light); border-radius: 3px; font-size: 0.8em; flex: 0 0 auto; width: auto; max-width: 100%; align-self: flex-start; align-items: center; gap: 8px; flex-wrap: wrap;">';
    usesHTML += '<span style="font-weight: 600; color: var(--color-text-dark-primary); white-space: nowrap;"><i class="fas fa-dragon" style="margin-right: 3px;"></i>Forms:</span>';
    usesHTML += '<span style="display: inline-flex; gap: 10px; flex-wrap: wrap;">';

    let totalUsed = 0;
    let totalMax = 0;

    for (const form of unlockedForms) {
        const featureName = `Draconic Form: ${form.label}`;
        const item = actor.items.find(i => i.name === featureName);
        const spent = item?.system?.uses?.spent ?? 0;
        const max   = item?.system?.uses?.max   ?? form.max;
        const remaining = Math.max(0, max - spent);
        const color = remaining === 0 ? "color: var(--color-level-error);" : "color: var(--color-level-success);";

        totalUsed += spent;
        totalMax += parseInt(max);

        usesHTML += `
            <span style="white-space: nowrap;">
                <span style="font-weight: 600;">${form.label}:</span>
                <span style="${color} font-weight: 700;">${remaining}/${max}</span>
            </span>
        `;
    }

    usesHTML += '</span>';

    if (unlockedForms.length > 1) {
        usesHTML += `<span style="white-space: nowrap; margin-left: 4px; padding-left: 8px; border-left: 1px solid var(--color-border-light); color: var(--color-text-dark-secondary);">Total: <strong>${totalUsed}</strong>/${totalMax}</span>`;
    }

    usesHTML += '</div>';

    // v14 ApplicationV2 compatible injection with fallbacks
    // Target sheet BODY first so we never disrupt the header / Long Rest buttons
    const target = element.querySelector('[data-application-part="content"]')
        || element.querySelector(".sheet-body")
        || element.querySelector(".window-content")
        || element.querySelector("form")
        || element.querySelector(".main")
        || element.querySelector(".character-header")
        || element.querySelector(".sheet-header")
        || element;

    const wrapper = document.createElement("div");
    wrapper.innerHTML = usesHTML;
    target.prepend(wrapper.firstElementChild);
    console.log("[Dragon Shifter] Bug 6: Injected compact Draconic Form Uses tracker.");
}

// Register on dnd5e v4 specific render hooks for uses tracker
Hooks.on("renderCharacterActorSheet", injectUsesTracker);
Hooks.on("renderNPCActorSheet", injectUsesTracker);
Hooks.on("renderGroupActorSheet", injectUsesTracker);

// V2 generic actor sheet hook
Hooks.on("renderActorSheetV2", injectUsesTracker);

// Fallback: also register on generic renderActorSheet for legacy sheets
Hooks.on("renderActorSheet", injectUsesTracker);

/* ────────────────────────────────────────────────────────────────────────────
   REVERT  —  dnd5e.revertOriginalForm hook + WORKAROUND for v4 _id bug
   ──────────────────────────────────────────────────────────────────────────── */

/**
 * WORKAROUND for dnd5e v4 revertOriginalForm _id bug.
 * The core method crashes when polymorphed actor items have null/undefined _id.
 * We monkey-patch the method to sanitize IDs before the core logic runs.
 */
function patchRevertOriginalForm() {
    if (!Actor.prototype.revertOriginalForm) return;

    const originalRevert = Actor.prototype.revertOriginalForm;
    Actor.prototype.revertOriginalForm = async function(options = {}) {
        if (!this.isPolymorphed) {
            console.log("[Dragon Shifter] revertOriginalForm: Actor is not polymorphed.");
            return originalRevert.call(this, options);
        }

        // Sanitize items to ensure every item has a valid _id before core revert runs
        const items = this.items;
        if (items && items.size > 0) {
            const updates = [];
            for (const item of items) {
                if (!item.id || item.id === null || item.id === undefined) {
                    // Generate a valid ObjectId-like string
                    const newId = foundry.utils.randomID();
                    updates.push({ _id: item._id || item.id, "flags.core.tempId": newId });
                    console.warn(`[Dragon Shifter] Patched missing _id for item "${item.name}" with temp ID ${newId}`);
                }
            }
            if (updates.length > 0) {
                try {
                    await this.updateEmbeddedDocuments("Item", updates);
                } catch (e) {
                    console.warn("[Dragon Shifter] Could not patch item IDs, attempting revert anyway:", e);
                }
            }
        }

        // Also clear our flags before revert to prevent stale data
        await this.unsetFlag("taos", "transformData");
        await this.unsetFlag("taos", "pendingTempHP");
        await this.unsetFlag("taos", "postTransformPending");
        await this.unsetFlag("taos", "postTransformProcessing");
        await this.unsetFlag("taos", "originalActorId");

        return originalRevert.call(this, options);
    };

    console.log("[Dragon Shifter] Patched Actor.prototype.revertOriginalForm for v4 _id bug.");
}

// Apply the patch on init
Hooks.on("init", () => {
    patchRevertOriginalForm();
});

Hooks.on("dnd5e.revertOriginalForm", async (actor, options) => {
    console.log("[Dragon Shifter] dnd5e.revertOriginalForm hook fired for", actor?.name);
    const transformData = actor.getFlag("taos", "transformData");
    if (!transformData) return;

    const now = game.time.worldTime;
    const elapsedSeconds = now - transformData.transformWorldTime;
    const elapsedHours   = elapsedSeconds / 3600;
    const hoursPastLimit = Math.max(0, elapsedHours - transformData.safeDuration);

    // Clear temp HP
    await actor.update({"system.attributes.hp.temp": 0});

    // Clean up all our flags
    await actor.unsetFlag("taos", "transformData");
    await actor.unsetFlag("taos", "pendingTempHP");
    await actor.unsetFlag("taos", "postTransformPending");
    await actor.unsetFlag("taos", "postTransformProcessing");
    await actor.unsetFlag("taos", "originalActorId");

    console.log(`[Dragon Shifter] Reverted. Elapsed: ${elapsedHours.toFixed(2)}h. Over limit: ${hoursPastLimit.toFixed(2)}h.`);

    if (hoursPastLimit > 0) {
        ui.notifications.warn(`Reverted after ${hoursPastLimit.toFixed(1)} hours past safe limit. Feral checks were required.`);
    } else {
        ui.notifications.info("Reverted to humanoid form safely.");
    }
});

/* ────────────────────────────────────────────────────────────────────────────
   BUG 7  —  Feral check using game world time
   ──────────────────────────────────────────────────────────────────────────── */

async function checkFeralStatus(actor, queueMissed = false) {
    const data = actor.getFlag("taos", "transformData");
    if (!data || data.isFeral) return;

    const now = game.time.worldTime;
    const elapsedSeconds = now - data.transformWorldTime;
    const elapsedHours   = elapsedSeconds / 3600;
    const hoursPastLimit = Math.max(0, elapsedHours - data.safeDuration);
    const newHoursPast   = Math.floor(hoursPastLimit);

    if (newHoursPast > data.hoursPastLimit) {
        const dc = 10 + newHoursPast;
        await actor.setFlag("taos", "transformData.hoursPastLimit", newHoursPast);
        await actor.setFlag("taos", "transformData.feralDC", dc);

        const startHour = queueMissed ? (data.hoursPastLimit + 1) : newHoursPast;
        for (let h = startHour; h <= newHoursPast; h++) {
            const checkDC = 10 + h;
            await createFeralCheckCard(actor, data.formType, h, checkDC, elapsedHours);
        }

        console.log(`[Dragon Shifter] Feral check triggered: ${newHoursPast}h past limit. DC ${dc}.`);
    }
}

async function createFeralCheckCard(actor, formType, hoursPast, dc, totalElapsedHours) {
    const safeDuration = actor.getFlag("taos", "transformData")?.safeDuration || 0;

    const content = `
        <div class="dragon-shifter-feral-check" style="border: 1px solid var(--color-border-highlight); border-radius: 4px; padding: 8px; background: rgba(212, 175, 55, 0.1);">
            <h3 style="margin: 0 0 6px 0; color: var(--color-level-warning);">⚠️ Feral Check Required</h3>
            <p style="margin: 2px 0;"><strong>${actor.name}</strong> has been in <strong>${formType}</strong> form for <strong>${totalElapsedHours.toFixed(1)} hours</strong>.</p>
            <p style="margin: 2px 0;">Safe duration: ${safeDuration} hours · Hours past limit: <strong>${hoursPast}</strong></p>
            <p style="margin: 6px 0; font-size: 1.1em;"><strong>Wisdom Saving Throw: DC ${dc}</strong></p>
            <p style="margin: 2px 0; font-size: 0.85em; color: var(--color-text-dark-secondary);">Failure: Character becomes feral (DM controls).<br>Success: Maintains control for another hour.</p>
            <div style="margin-top: 8px;">
                <button type="button" class="dragon-shifter-save" data-actor-id="${actor.id}" data-dc="${dc}" style="background: var(--color-border-highlight); color: white; border: none; padding: 6px 14px; border-radius: 4px; cursor: pointer; font-family: var(--font-primary);">
                    <i class="fas fa-dice-d20"></i> Roll Wisdom Save (DC ${dc})
                </button>
            </div>
        </div>
    `;

    const gmUsers = game.users.filter(u => u.isGM).map(u => u.id);
    const playerId = Object.entries(actor.ownership).find(([id, lvl]) => id !== "default" && lvl >= CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER)?.[0];
    const whisperTargets = [...new Set([...gmUsers, playerId].filter(Boolean))];

    await ChatMessage.create({
        content: content,
        speaker: {alias: "Dragon Shifter System"},
        whisper: whisperTargets
    });
}

Hooks.on("renderChatMessage", (message, html, data) => {
    const btn = html.find(".dragon-shifter-save")[0];
    if (!btn) return;

    btn.addEventListener("click", async () => {
        const actorId = btn.dataset.actorId;
        const dc = parseInt(btn.dataset.dc);
        const actor = game.actors.get(actorId);
        if (!actor) return ui.notifications.error("Actor not found.");
        if (!actor.isOwner) return ui.notifications.warn("You do not control this character.");

        let roll;
        if (actor.rollAbilitySave) {
            roll = await actor.rollAbilitySave("wis", {targetValue: dc, chatMessage: true});
        } else {
            const formula = `1d20 + ${actor.system.abilities.wis?.save ?? 0}`;
            roll = await new Roll(formula).evaluate();
            await roll.toMessage({
                speaker: ChatMessage.getSpeaker({actor}),
                flavor: `Wisdom Saving Throw (DC ${dc}) — Feral Check`
            });
        }

        if (!roll) return;

        const total = roll.total ?? roll.result;
        const success = total >= dc;

        if (success) {
            ChatMessage.create({
                content: `<p><strong style="color: var(--color-level-success);">✅ ${actor.name} maintains control!</strong> Wisdom save succeeded (${total} vs DC ${dc}).</p>`,
                speaker: {alias: "Dragon Shifter System"}
            });
        } else {
            await actor.setFlag("taos", "transformData.isFeral", true);
            ChatMessage.create({
                content: `<p><strong style="color: var(--color-level-error);">🐉 ${actor.name} has Gone Feral!</strong> Wisdom save failed (${total} vs DC ${dc}). The DM now controls this character.</p>`,
                speaker: {alias: "Dragon Shifter System"}
            });
            actor.sheet?.render(false);
        }
    });
});

Hooks.on("updateWorldTime", async (worldTime, dt) => {
    for (const actor of game.actors) {
        await checkFeralStatus(actor, false);
    }
});

setInterval(() => {
    for (const actor of game.actors) {
        if (isPolymorphed(actor) && actor.getFlag("taos", "transformData")) {
            actor.sheet?.render(false);
        }
    }
}, 60000);
